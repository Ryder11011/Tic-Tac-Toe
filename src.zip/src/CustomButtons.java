import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class CustomButtons extends JButton {
    private Color backgroundColor = new Color(242, 177, 55);
    private Color textColor = new Color(30, 10, 50);
    private int cornerRadius = 20;

    public CustomButtons(String label) {
        super(label);

        setContentAreaFilled(false);
        setFocusPainted(false);
        setBorderPainted(false);
        setSize(200, 60);

        setForeground(textColor);
        setFont(new Font("SansSerif", Font.BOLD, 14));
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        ButtonModel model = getModel();

        if (model.isPressed()) {
            g2.setColor(backgroundColor.darker());
        }
        else if (model.isRollover()) {
            g2.setColor(new Color(255, 200, 100));
        }
        else {
            g2.setColor(backgroundColor);
        }

        int offset = model.isPressed() ? 2 : 0;

        g2.fill(new RoundRectangle2D.Double(offset, offset,
                getWidth() - offset, getHeight() - offset,
                cornerRadius, cornerRadius));

        if (model.isRollover() && !model.isPressed()) {
            g2.setColor(textColor);
            g2.setStroke(new BasicStroke(1f));
            g2.draw(new RoundRectangle2D.Double(0, 0, getWidth() - 1, getHeight() - 1, cornerRadius, cornerRadius));
        }

        g2.dispose();

        if (model.isPressed()) {
            g.translate(2, 2);
        }
        super.paintComponent(g);
    }
}