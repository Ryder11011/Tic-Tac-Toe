import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GUI extends JPanel {

    // --- BUTTONS DEFINED BY NAME ---
    JButton btnTopLeft, btnTopCenter, btnTopRight;
    JButton btnMidLeft, btnMidCenter, btnMidRight;
    JButton btnBotLeft, btnBotCenter, btnBotRight;

    // --- COLORS ---
    final Color BG_DARK    = new Color(30, 10, 50);
    final Color BUTTON_BG  = new Color(45, 25, 70);
    final Color X_CYAN     = new Color(49, 196, 249);
    final Color O_YELLOW   = new Color(242, 177, 55);

    public GUI() {
        setSize(500, 500);
        setLayout(null);
        setBackground(BG_DARK);

        // Row 1
        btnTopLeft = XandOButton(45 + 50, 140 - 30);
        btnTopCenter = XandOButton(150 + 50, 140 - 30);
        btnTopRight = XandOButton(255 + 50, 140 - 30);

        // Row 2
        btnMidLeft = XandOButton(45 + 50, 245 - 30);
        btnMidCenter = XandOButton(150 + 50, 245 - 30);
        btnMidRight = XandOButton(255 + 50, 245 - 30);

        // Row 3
        btnBotLeft = XandOButton(45 + 50, 350 - 30);
        btnBotCenter = XandOButton(150 + 50, 350 - 30);
        btnBotRight  = XandOButton(255 + 50, 350 - 30);

        // Add them to the Mframe
        add(btnTopLeft);
        add(btnTopCenter);
        add(btnTopRight);
        add(btnMidLeft);
        add(btnMidCenter);
        add(btnMidRight);
        add(btnBotLeft);
        add(btnBotCenter);
        add(btnBotRight);
    }

    private JButton XandOButton(int x, int y) {
        JButton btn = new JButton("");
        btn.setBounds(x, y, 95, 95);
        btn.setBackground(BUTTON_BG);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setFont(new Font("Arial", Font.BOLD, 55));

        btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buttonFunction(btn);
            }
        });
        return btn;
    }

    public void buttonFunction(JButton btn) { }

}