import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MessageBox {
    JFrame Mframe = new JFrame();
    JPanel panel = new JPanel();
    JLabel lostLabel = new JLabel();
    CustomButtons resetButton = new CustomButtons("Reset");
    String label;

    MessageBox(String Label) {
        label = Label;
    }

    public void ShowMessageBox() {
        Mframe.setExtendedState(JFrame.MAXIMIZED_BOTH);
        Mframe.setLayout(null);
        //Mframe.getContentPane().setBackground(new Color(30, 10, 50));
        Mframe.setUndecorated(true);
        Mframe.setBackground(new Color(0, 0, 0, 150));
        //Mframe.setOpacity(0.1F);
        Mframe.setVisible(true);

        panel.setSize(500, 300);
        panel.setLocation((Mframe.getWidth() / 2) - (panel.getWidth() / 2), (Mframe.getHeight() / 2) - (panel.getHeight() / 2));
        panel.setLayout(null);
        panel.setOpaque(true);
        panel.setBackground(new Color(30, 10, 50));
        panel.setVisible(true);
        Mframe.add(panel);

        lostLabel.setText(label);
        lostLabel.setForeground(Color.WHITE);
        lostLabel.setFont(new Font("Arial", Font.BOLD, 40));
        lostLabel.setHorizontalAlignment(SwingConstants.CENTER);
        lostLabel.setSize(400, 60);
        lostLabel.setLocation((panel.getWidth() - lostLabel.getWidth()) / 2, (panel.getHeight() / 2) - 80);
        panel.add(lostLabel);

        resetButton.setLocation((panel.getWidth() / 2) - (resetButton.getWidth() / 2), (panel.getHeight() / 2) - (resetButton.getHeight() / 2) + 100);
        resetButton.setVisible(true);
        panel.add(resetButton);
    }

}
