import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainMenu {
    JFrame frame = new JFrame();
    JPanel mainPanel = new JPanel();
    JPanel midPanel = new JPanel();
    CustomButtons AIbutton = new CustomButtons("AI Enemy");
    CustomButtons AlgButton = new CustomButtons("Math Enemy");

    MainMenu() {
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setVisible(true);
        frame.setLayout(null);

        mainPanel.setSize(frame.getSize());
        mainPanel.setVisible(true);
        mainPanel.setLayout(null);
        mainPanel.setBackground(new Color(45, 25, 70));
        frame.add(mainPanel);

        midPanel.setSize(500, 600);
        midPanel.setBackground(new Color(30, 10, 50));
        midPanel.setLocation((frame.getWidth() / 2) - (midPanel.getWidth() / 2), (frame.getHeight() / 2) - (midPanel.getHeight() / 2) - 50);
        midPanel.setLayout(null);
        mainPanel.add(midPanel);

        AIbutton.setLocation((midPanel.getWidth() / 2) - (AIbutton.getWidth() / 2), (midPanel.getHeight() / 2) - (AIbutton.getHeight() / 2) - 50);
        midPanel.add(AIbutton);

        AlgButton.setLocation((midPanel.getWidth() / 2) - (AlgButton.getWidth() / 2), (midPanel.getHeight() / 2) - (AlgButton.getHeight() / 2) + 50);
        midPanel.add(AlgButton);

        AIbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Background2 back = new Background2();
                frame.dispose();
            }
        });

        AlgButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Background back = new Background();
                frame.dispose();
            }
        });
    }

    public static void main(String[] args) {
        MainMenu menu = new MainMenu();
    }
}
