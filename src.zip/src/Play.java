import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Objects;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicInteger;

public class Play extends GUI {
    JButton[][] buttonPlayGround = new JButton[3][3];
    Xmovement engine = new Xmovement();
    boolean win;
    MessageBox messageBox = new MessageBox("You Lose");
    Background back;

    Play(Background background) {
        mapping(ThreadLocalRandom.current().nextInt(1, 4));

        engine.playGround[0][0] = 1;
        mapButtons();
        engine.counter++;
        back = background;
    }

    public void mapping(int number) {
        if (number == 1) {
            buttonPlayGround[0][0] = btnTopLeft;
            buttonPlayGround[0][1] = btnTopCenter;
            buttonPlayGround[0][2] = btnTopRight;
            buttonPlayGround[1][0] = btnMidLeft;
            buttonPlayGround[1][1] = btnMidCenter;
            buttonPlayGround[1][2] = btnMidRight;
            buttonPlayGround[2][0] = btnBotLeft;
            buttonPlayGround[2][1] = btnBotCenter;
            buttonPlayGround[2][2] = btnBotRight;
        }
        else if (number == 2) {
            buttonPlayGround[0][0] = btnTopRight;
            buttonPlayGround[0][1] = btnTopCenter;
            buttonPlayGround[0][2] = btnTopLeft;
            buttonPlayGround[1][0] = btnMidRight;
            buttonPlayGround[1][1] = btnMidCenter;
            buttonPlayGround[1][2] = btnMidLeft;
            buttonPlayGround[2][0] = btnBotRight;
            buttonPlayGround[2][1] = btnBotCenter;
            buttonPlayGround[2][2] = btnBotLeft;
        }
        else if (number == 3) {
            buttonPlayGround[0][0] = btnBotLeft;
            buttonPlayGround[0][1] = btnBotCenter;
            buttonPlayGround[0][2] = btnBotRight;
            buttonPlayGround[1][0] = btnMidLeft;
            buttonPlayGround[1][1] = btnMidCenter;
            buttonPlayGround[1][2] = btnMidRight;
            buttonPlayGround[2][0] = btnTopLeft;
            buttonPlayGround[2][1] = btnTopCenter;
            buttonPlayGround[2][2] = btnTopRight;
        }
    }

    private void mapButtons() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (engine.playGround[i][j] == -1) {
                    buttonPlayGround[i][j].setText("O");
                    buttonPlayGround[i][j].setForeground(O_YELLOW);
                }
                else if (engine.playGround[i][j] == 1) {
                    buttonPlayGround[i][j].setText("X");
                    buttonPlayGround[i][j].setForeground(X_CYAN);
                }
            }
        }
    }

    private void mapMatrix() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (Objects.equals(buttonPlayGround[i][j].getText(), "X")) {
                    engine.playGround[i][j] = 1;
                } else if (Objects.equals(buttonPlayGround[i][j].getText(), "O")) {
                    engine.playGround[i][j] = -1;
                }
            }
        }
    }

    public void setWin() {

        messageBox.resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                back.mainPanel.remove(back.gui);
                back.gui = new Play(back);
                back.gui.setLocation((back.frame.getWidth() / 2) - (back.gui.getWidth() / 2), (back.frame.getHeight() / 2) - (back.gui.getHeight() / 2) - 50);
                back.gui.setVisible(true);
                back.mainPanel.add(back.gui);
                back.mainPanel.revalidate();
                back.mainPanel.repaint();
                messageBox.Mframe.dispose();
            }
        });
        messageBox.ShowMessageBox();
    }

    @Override
    public void buttonFunction(JButton btn) {
        if (Objects.equals(btn.getText(), "")) {
            btn.setText("O");
            btn.setForeground(O_YELLOW);
            mapMatrix();
            win = engine.xMove();
            mapButtons();
            if (win) {
                setWin();
            }
        }
    }
}
