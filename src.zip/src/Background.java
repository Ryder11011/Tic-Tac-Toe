import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Background {
    JFrame frame = new JFrame();
    JPanel mainPanel = new JPanel();
    JPanel sidePanel = new JPanel();
    Background back = this;
    Play gui = new Play(this);
    CustomButtons resetButton = new CustomButtons("Reset");
    JButton button = new JButton();
    CustomButtons menu = new CustomButtons("Main Menu");

    Background() {
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setVisible(true);
        frame.setLayout(null);

        mainPanel.setSize(frame.getSize());
        mainPanel.setVisible(true);
        mainPanel.setLayout(null);
        mainPanel.setBackground(new Color(45, 25, 70));
        frame.add(mainPanel);

        sidePanel.setSize(300, mainPanel.getHeight());
        sidePanel.setBackground(new Color(30, 10, 50));
        sidePanel.setLocation(0, 0);
        sidePanel.setLayout(null);
        mainPanel.add(sidePanel);


        gui.setLocation((frame.getWidth() / 2) - (gui.getWidth() / 2), (frame.getHeight() / 2) - (gui.getHeight() / 2) - 50);
        gui.setVisible(true);
        mainPanel.add(gui);

        //resetButton.setSize(200, 100);
        resetButton.setLocation((int)(gui.getLocation().getX() + ((double) gui.getWidth() / 2)) - (resetButton.getWidth() / 2), (int)(gui.getLocation().getY() + gui.getHeight()) + 30);
        resetButton.setVisible(true);
        resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                reset();
            }
        });
        mainPanel.add(resetButton);

        menu.setLocation((sidePanel.getWidth() / 2) - (menu.getWidth() / 2), (sidePanel.getHeight() / 2) - (menu.getHeight() / 2) - 50);
        sidePanel.add(menu);

        menu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                MainMenu menuOpen = new MainMenu();
                frame.dispose();
            }
        });
    }

    public void reset() {
        mainPanel.remove(gui);
        gui = new Play(back);
        gui.setLocation((frame.getWidth() / 2) - (gui.getWidth() / 2), (frame.getHeight() / 2) - (gui.getHeight() / 2) - 50);
        gui.setVisible(true);
        mainPanel.add(gui);
        mainPanel.revalidate();
        mainPanel.repaint();
    }
}
